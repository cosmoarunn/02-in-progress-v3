Get more awesome background patterns like these from:

http://subtlepatterns.com


Note: if you use any of the "Arc" versions of Sprout, you will have to
change the background of the bg-arc.png image as well, to the new texture.
"bg-arc.PSD" can be found in the PSD folder.