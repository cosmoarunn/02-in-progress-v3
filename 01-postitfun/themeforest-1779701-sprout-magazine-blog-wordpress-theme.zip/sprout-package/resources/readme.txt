Supported Plugins:
WP-Pagenavi - http://wordpress.org/extend/plugins/wp-pagenavi/

Logo Font:
Gotham Black

Content Font:
Arial
Oswald: http://www.google.com/webfonts#UsePlace:use/Collection:Oswald
