=== WP-Popular Posts Tool ===
Donate link: http://teofiloisrael.com/plugin-pupular-posts-tool/
Demo link: http://emovilpro.com
Tags: categories, tags, popular posts, popular posts by category, popular posts by tag, most commented posts by category, most commented posts by tag
Requires at least: 2.3
Tested up to: 2.8
Stable tag: 1.1.1

== Description ==

Enables you to automatically display most commented posts, either by category or tag. Optional: You can choose manually the category or tag you want to display its most commented posts. It has a widget to add it easily to your sidebar. See this plugin in action in http://emovilpro.com
== Installation ==

Installation:

1. Upload files to your `/wp-content/plugins/` directory (preserve sub-directory structure if applicable)
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to Design->Widgets in your WordPress Admin panel. Look for a Widget named Wp-Popular Posts Widget and add it to your sidebar
4. Refer to the official plugin page for documentation, usage and tips