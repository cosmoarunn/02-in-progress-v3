<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

<!-- Basic Page Needs -->
<meta charset="utf-8">
<title>Responsive Hotel  Site template</title>
<meta name="description" content="Responsive Hotel  Site template">
<meta name="author" content="">
<!-- Google web font -->
<link href='http://fonts.googleapis.com/css?family=Terminal+Dosis|PT+Sans+Narrow:400,700|Nothing+You+Could+Do' rel='stylesheet' type='text/css'>

<!-- Mobile Specific Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS -->
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/menu.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" href="css/layout.css">
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!-- Favicons-->
<link rel="shortcut icon" href="images/favicon.ico">
<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
    
<!-- Jquery -->
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
<!-- Exposè, tabs, accordion-->
<script src="http://cdn.jquerytools.org/1.2.6/all/jquery.tools.min.js"></script>
</head>
<body>
<header>
<div class="container">
	<div class=" four columns" id="logo"><a href="index.html">Paradise hotel</a></div>
	<div class="twelve columns">
		<ul id="lang">
			<li>En</li>
			<li><a href="#">Fr</a></li>
			<li><a href="#">Es</a></li>
		</ul>
		<div id="wxWrap"><span id="wxIntro">Currently here</span><span id="wxIcon2"></span><span id="wxTemp"></span></div><!-- weather -->
	</div>
    <!-- start main nav -->
	<div class="twelve columns">
		<nav>
		<ul id="main-nav" class="sf-menu">
			<li><a href="#">Home</a>
			<ul>
				<li><a href="index.html">Home slider</a></li>
				<li><a href="index_2.html">Home fullscreen</a></li>
			</ul>
			</li>
			<li><a href="rooms.html">Rooms</a></li>
			<li><a href="#">Pages</a>
			<ul>
				<li><a href="about.html">About</a></li>
				<li><a href="fullscreen_gallery.html">Fullscreen gallery</a></li>
				<li><a href="gallery_columns.html">Gallery grids</a></li>
				<li><a href="rooms_2.html">Rooms 2</a></li>
			</ul>
			</li>
			<li><a href="contacts.html">Contact us</a></li>
			<li><a href="#">Purchase</a></li>
		</ul>
		</nav><!-- end main nav -->
	</div><!-- end twelve -->
</div><!-- end container -->
</header><!-- end header-->

<div class="container add-bottom_2">
	<div class="sixteen columns add-bottom">
		<h1>Contact us<span>Lorem ipsum dolor sit amet, per ne purto corpora, cu eam cetero dolores.</span></h1>
	</div>
    
	<div class="sixteen columns ">
		<div class="map_canvas add-bottom" data-lat="39.621557" data-lng="0.370233" data-address="Palma, Spain" data-zoom="10" data-maptitle="Paradise Hotel" style="height:275px;width:100%;">
	</div><!-- end map-->
        
		<div class="one-third column alpha half-bottom">
			<h3 id="airport">From the airport</h3>
			<ul class="list_4">
				<li>Vix in error iuvaret, at omnium prompta aliquam vel. Sea an purto vide posidonium, eos modus dicit ne. Appetere dignissim vis et. </li>
				<li>Appetere dignissim vis et. Te per dolore expetenda voluptaria, an eam autem perfecto patrioque. Eu eum inermis verterem assentior.</li>
			</ul>
		</div><!-- end airport one-third -->
        
		<div class="one-third column half-bottom">
			<h3 id="station">Form the station</h3>
			<ul class="list_4">
				<li>Vix in error iuvaret, at omnium prompta aliquam vel. Sea an purto vide posidonium, eos modus dicit ne. Appetere dignissim vis et. </li>
				<li>Appetere dignissim vis et. Te per dolore expetenda voluptaria, an eam autem perfecto patrioque. Eu eum inermis verterem assentior.</li>
			</ul>
		</div><!-- end station one-third -->
        
		<div class="one-third column omega half-bottom">
			<h3 id="car">By car</h3>
			<ul class="list_4">
				<li>Vix in error iuvaret, at omnium prompta aliquam vel. Sea an purto vide posidonium, eos modus dicit ne. Appetere dignissim vis et. </li>
				<li>Appetere dignissim vis et. Te per dolore expetenda voluptaria, an eam autem perfecto patrioque. Eu eum inermis verterem assentior.</li>
			</ul>
		</div><!-- end car one-third -->

		<hr>
        
		<div class=" sixteen columns alpha">
			<div class="one-third column alpha">
				<ul>
					<li><strong>Street Number & Name</strong>, Postal Code 2034 BXU</li>
					<li>+353 1 234 566 78 / +353 1 234 566 78</li>
					<li><a href="#">info@emailaddress.com</a> - <a href="#">www.paradise.com</a></li>
				</ul>
				<ul id="follow" class="add-bottom">
					<li><a href="#" id="tw">Twitter</a></li>
					<li><a href="#" id="rss">Rss</a></li>
					<li><a href="#" id="vimeo">Vimeo</a></li>
					<li><a href="#" id="fb">Facebook</a></li>
				</ul>
			</div>
        <?php
		if (!count($_POST)){
		?>		
        <a name="f"></a>			
			<form method="post" id="myform" action="<?php echo $_SERVER['PHP_SELF']; ?>#f">
			  <div class="one-third column ">
					<fieldset>
						<label>Name</label>
						<input name="name" class="required long" type="text"/>
						<label>Last Name</label>
						<input name="last_name" class="required long" type="text"/>
						<label> Email</label>
						<input name="email" class="required email long" type="email"/>
					</fieldset>
				</div>
				<div class="one-third column omega">
					<fieldset>
						<label> Message</label>
						<textarea name="message" class="required" style="width:95%; height:75px"></textarea>
					</fieldset>
					<button type="submit" class="button">Send Message</button>
				</div>
			</form>
            <?php
		}else{
	    ?>
       <!-- START SEND MAIL SCRIPT -->
       
        <div class=" one-third column" align="center">
        <img src="img/sent.png" width="150" height="150" alt="Sent">
      </div>
      <div class=" one-third column omega" style="padding-top:68px">
     <p><strong>Email Successfully Sent!</strong></p>
      </div>
     
						
						<?php
						$mail = $_POST['email'];

						/*$subject = "".$_POST['subject'];*/
						$to = "info@ansonika.com";
						$subject = "Message from Paradise Hotel web site";
						$headers = "From: Paradise Hotel <noreply@yourdomain.com>";
						$message = "Message\n";
						$message .= "\nName: " . $_POST['name'];
						$message .= "\nLast Name: " . $_POST['last_name'];
						$message .= "\nEmail: " . $_POST['email'];
						$message .= "\nMessage: " . $_POST['message'];
						
						//Receive Variable
						$sentOk = mail($to,$subject,$message,$headers);
						}
						?>
						<!-- END SEND MAIL SCRIPT -->   
		</div>
	</div>
</div>

<footer>
    <div class="container">
        <nav class="eleven columns">
        <ul id="nav-footer">
            <li><a href="rooms.html">Rooms</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="rooms.html">Book now</a></li>
            <li><a href="fullscreen_gallery.html">Gallery</a></li>
            <li><a href="contacts.html">Contacts </a></li>
        </ul>
        </nav>
    <div class="five columns copy">© 2012 Paradise Hotel. All Rights Reserved.</div>
    </div>
</footer><!-- footer  -->

<!-- JQUERY plugins: Moderniz, Prettyphoto, Flexislider, MobileMenu, SuperfishMenu, Weather, Tooltip-->	
<!-- Google Maps API -->	
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script type="text/javascript" src="js/google_map.js"></script>
<script type="text/javascript"  src="js/plug_ins.js"></script>  
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script>
  $(document).ready(function(){
    $("#myform").validate();
	$(":date").dateinput();
  });
  </script>
<script src="js/functions.js"></script>
</body>
</html>