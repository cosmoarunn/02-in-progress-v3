<!DOCTYPE html>
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="en"> <!--<![endif]-->
<head>

<!-- Basic Page Needs -->
<meta charset="utf-8">
<title>Responsive Hotel  Site template</title>
<meta name="description" content="Responsive Hotel  Site template">
<meta name="author" content="">
<!-- Google web font -->
<link href='http://fonts.googleapis.com/css?family=Terminal+Dosis|PT+Sans+Narrow:400,700|Nothing+You+Could+Do' rel='stylesheet' type='text/css'>

<!-- Mobile Specific Metas -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS -->
<link rel="stylesheet" href="css/base.css">
<link rel="stylesheet" href="css/skeleton.css">
<link rel="stylesheet" href="css/menu.css">
<link rel="stylesheet" href="css/layout.css">
<link rel="stylesheet" href="css/calendar.css">

<!-- prettyPhoto plugin -->
<link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css" type="text/css" media="screen">
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->

<!-- Favicons-->
<link rel="shortcut icon" href="img/favicon.ico">
<link rel="apple-touch-icon" href="img/apple-touch-icon.png">
<link rel="apple-touch-icon" sizes="72x72" href="img/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="114x114" href="img/apple-touch-icon-114x114.png">
   
    
<!-- Jquery -->
<script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>

<!-- Exposè, tabs, accordion-->
<script src="http://cdn.jquerytools.org/1.2.6/all/jquery.tools.min.js"></script>

</head>
<body>
<header>
<div class="container">
	<div class=" four columns" id="logo"><a href="index.html">Paradise hotel</a></div>
	<div class="twelve columns">
		<ul id="lang">
			<li>En</li>
			<li><a href="#">Fr</a></li>
			<li><a href="#">Es</a></li>
		</ul>
		<div id="wxWrap"><span id="wxIntro">Currently here</span><span id="wxIcon2"></span><span id="wxTemp"></span></div><!-- weather -->
	</div>
    <!-- start main nav -->
	<div class="twelve columns">
		<nav>
		<ul id="main-nav" class="sf-menu">
			<li><a href="#">Home</a>
			<ul>
				<li><a href="index.html">Home slider</a></li>
				<li><a href="index_2.html">Home fullscreen</a></li>
			</ul>
			</li>
			<li><a href="rooms.html">Rooms</a></li>
			<li><a href="#">Pages</a>
			<ul>
				<li><a href="about.html">About</a></li>
				<li><a href="fullscreen_gallery.html">Fullscreen gallery</a></li>
				<li><a href="gallery_columns.html">Gallery grids</a></li>
				<li><a href="rooms_2.html">Rooms 2</a></li>
			</ul>
			</li>
			<li><a href="contacts.html">Contact us</a></li>
			<li><a href="#">Purchase</a></li>
		</ul>
		</nav><!-- end main nav -->
	</div><!-- end twelve -->
</div><!-- end container -->
</header><!-- end header-->

<div class="container">
	<div class="sixteen columns add-bottom">
		<h1>Rooms available<span>Lorem ipsum dolor sit amet, per ne purto corpora, cu eam cetero dolores.</span></h1>
	</div>
    
	<div class="eleven columns">
    
    	<!-- start room -->
		<div class="four columns picture alpha">
			<a href="img/room_1_room_page_2_big.jpg" data-rel="prettyPhoto" title=""><span class="magnify"></span><img src="img/room_1.jpg" alt="" class="scale-with-grid"></a>
			<em></em><!-- end room picture-->
	  </div>
		<div class="seven columns omega">
			<h3>Single room <strong>110$</strong><span> Pellentesque amet adipiscing scelerisque</span></h3>
			<p>
				 Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada. Erat in tempor magna, eget porttitor posuere, commodo a eu diam vulputate erat ullamcorper.
			</p>
			<ul class="room_facilities">
				<li class="lcd"><a class="tooltip_1" href="#" title="LCD TV">LCD TV</a></li>
				<li class="wifi"><a class="tooltip_1" href="#" title="Wifi broadband access">Wifi broadband access</a></li>
				<li class="breakfast"><a class="tooltip_1" href="#" title="Breakfast included">Breakfast included</a></li>
				<li class="safe"><a class="tooltip_1" href="#" title="Safe-deposit box">Safe-deposit box</a></li>
				<li class="bath"><a class="tooltip_1" href="#" title="Large master bathroom">Large master bathroom</a></li>
				<li class="dinner"><a class="tooltip_1" href="#" title="Dinner included">Dinner included</a></li>
				<li class="parking"><a class="tooltip_1" href="#" title="Parking">Parking</a></li>
				<li class="loundry"><a class="tooltip_1" href="#" title="Loundry service">Loundry service</a></li>
			</ul>
			<br class="clear add-bottom"/>
			<div class="rate">
				<div id="r1" class="rate_wd">
					<div class="star_1 ratings_stars"></div>
                    <div class="star_2 ratings_stars"></div>
					<div class="star_3 ratings_stars"></div>
					<div class="star_4 ratings_stars"></div>
					<div class="star_5 ratings_stars"></div>
					<div class="total_votes">vote data</div>
				</div>
			</div><!-- end rate-->
		</div><!-- end  room-->
		<hr>
        
        <!-- start room -->
		<div class="four columns picture alpha">
			<a href="img/room_2_room_page_2_big.jpg" data-rel="prettyPhoto" title=""><span class="magnify"></span><img src="img/room_2.jpg" alt="" class="scale-with-grid"></a>
			<em></em><!-- end room picture-->
	  </div>
		<div class="seven columns omega">
			<h3>Double room <strong>180$</strong><span> Pellentesque amet adipiscing scelerisque</span></h3>
			<p>
				 Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada. Erat in tempor magna, eget porttitor posuere, commodo a eu diam vulputate erat ullamcorper.
			</p>
			<ul class="room_facilities">
				<li class="lcd"><a class="tooltip_1" href="#" title="LCD TV">LCD TV</a></li>
				<li class="wifi"><a class="tooltip_1" href="#" title="Wifi broadband access">Wifi broadband access</a></li>
				<li class="breakfast"><a class="tooltip_1" href="#" title="Breakfast included">Breakfast included</a></li>
				<li class="safe"><a class="tooltip_1" href="#" title="Safe-deposit box">Safe-deposit box</a></li>
				<li class="bath"><a class="tooltip_1" href="#" title="Large master bathroom">Large master bathroom</a></li>
				<li class="dinner"><a class="tooltip_1" href="#" title="Dinner included">Dinner included</a></li>
				<li class="parking"><a class="tooltip_1" href="#" title="Parking">Parking</a></li>
				<li class="loundry"><a class="tooltip_1" href="#" title="Loundry service">Loundry service</a></li>
			</ul>
			<br class="clear add-bottom"/>
			<div class="rate">
				<div id="r2" class="rate_wd">
					<div class="star_1 ratings_stars"></div>
                    <div class="star_2 ratings_stars"></div>
					<div class="star_3 ratings_stars"></div>
					<div class="star_4 ratings_stars"></div>
					<div class="star_5 ratings_stars"></div>
					<div class="total_votes">vote data</div>
				</div>
			</div><!-- end rate-->
		</div><!-- end content room-->
        
		<hr>
        
        <!-- start room -->
		<div class="four columns picture alpha">
			<a href="img/room_3_room_page_2_big.jpg" data-rel="prettyPhoto" title=""><span class="magnify"></span><img src="img/room_3.jpg" alt="" class="scale-with-grid"></a>
			<em></em><!-- end room picture-->
	  </div>
		<div class="seven columns omega">
			<h3>Suite room <strong>210$</strong><span> Pellentesque amet adipiscing scelerisque</span></h3>
			<p>
				 Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada. Erat in tempor magna, eget porttitor posuere, commodo a eu diam vulputate erat ullamcorper.
			</p>
			<ul class="room_facilities">
				<li class="lcd"><a class="tooltip_1" href="#" title="LCD TV">LCD TV</a></li>
				<li class="wifi"><a class="tooltip_1" href="#" title="Wifi broadband access">Wifi broadband access</a></li>
				<li class="breakfast"><a class="tooltip_1" href="#" title="Breakfast included">Breakfast included</a></li>
				<li class="safe"><a class="tooltip_1" href="#" title="Safe-deposit box">Safe-deposit box</a></li>
				<li class="bath"><a class="tooltip_1" href="#" title="Large master bathroom">Large master bathroom</a></li>
				<li class="dinner"><a class="tooltip_1" href="#" title="Dinner included">Dinner included</a></li>
				<li class="parking"><a class="tooltip_1" href="#" title="Parking">Parking</a></li>
				<li class="loundry"><a class="tooltip_1" href="#" title="Loundry service">Loundry service</a></li>
			</ul>
			<br class="clear add-bottom"/>
			<div class="rate">
				<div id="r3" class="rate_wd">
					<div class="star_1 ratings_stars"></div>
                    <div class="star_2 ratings_stars"></div>
					<div class="star_3 ratings_stars"></div>
					<div class="star_4 ratings_stars"></div>
					<div class="star_5 ratings_stars"></div>
					<div class="total_votes">vote data</div>
				</div>
			</div><!-- end rate-->
		</div><!-- end content room-->
        
		<hr>
		<p>
			 Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada. Erat in tempor magna, eget porttitor posuere, commodo a eu diam vulputate erat ullamcorper.
		</p>
        
        <!-- start pricing table -->
		<table class="add-bottom_2">
		<thead>
		<tr>
			<th>Room Type</th>
			<th>Low<br>from 23/03 to 31/05</th>
			<th>Middle<br>from 23/03 to 31/05</th>
			<th>High<br>from 23/03 to 31/05</th>
		</tr>
        
		</thead>
		<tbody>
		<tr>
			<td>Single</td>
			<td>99$</td>
			<td>120$</td>
			<td>140$</td>
		</tr>
		<tr>
			<td>Double</td>
			<td>120$</td>
			<td>150$</td>
			<td>180$</td>
		</tr>
		<tr>
			<td>Suite</td>
			<td>140$</td>
			<td>170$</td>
			<td>200$</td>
		</tr>
		</tbody>
		</table>
    </div><!-- end column left - rooms list -->
    
    <!-- start col right -->
	<section class="five columns omega">
    <?php
		if (!count($_POST)){
		?>				
	<!-- start check avail-->
	<div id="check_avail" class="expose add-bottom">
          <h2>Check Availability</h2>
		<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" id="myform">
			<fieldset class="col_f_1">
				<label>Check in</label><input name="checkin" type="date" class="required calendar">
			</fieldset>
			<fieldset class="col_f_2">
				<label>Check out</label><input name="checkout" type="date" class="required calendar">
			</fieldset>
			<br class="clear">
			<fieldset class="col_f_1">
				<label>N°of guest</label>
				<select name="guest" class="required">
					<option value="">- please select -</option>
					<option>One</option>
					<option>Two</option>
					<option>Three</option>
					<option>Four</option>
				</select>
			</fieldset>
			<fieldset class="col_f_2">
				<label>Room type</label>
				<select name="rooms" class="required">
					<option value="">- please select -</option>
					<option>Single room</option>
					<option>Double Room</option>
					<option>Suite</option>
				</select>
			</fieldset>
			<br class="clear "/>
			<fieldset>
				<label>Your Name</label><input type="text" name="name" class="required long"/>
				<label>Your Email</label><input type="email" name="email" class="required email long">
			</fieldset>
			<button type="submit">Check</button>
		</form>
         <?php
		}else{
	    ?>
      
       <!-- START SEND MAIL SCRIPT -->
       <div id="check_avail" class="expose add-bottom">

        <div align="center">
        <p><img src="img/sent.png" width="150" height="150" alt="Sent"></p>
		<p><strong>Request Successfully Sent!</strong><br />
		  We will contact you shortly to confirm your request!</p>
      </div>
						
						<?php
						$mail = $_POST['email'];

						/*$subject = "".$_POST['subject'];*/
						$to = "info@ansonika.com";
						$subject = "Request Room Availability Paradise Hotel";
						$headers = "From: Paradise Hotel <noreply@yourdomain.com>";
						$message = "Request Room Availability\n";
						$message .= "\nCheck in: " . $_POST['checkin'];
						$message .= "\nCheck out: " . $_POST['checkout'];
						$message .= "\nNumber of guest: " . $_POST['guest'];
						$message .= "\nType of room: " . $_POST['rooms'];
						$message .= "\nName: " . $_POST['name'];
						$message .= "\nEmail: " . $_POST['email'];
						
						//Receive Variable
						$sentOk = mail($to,$subject,$message,$headers);
						}
						?>
						<!-- END SEND MAIL SCRIPT -->   
    <hr>
		<h4>Book by phone</h4>
		<p>
			 Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada.
		</p>
		<p>
			<strong>0044 439 4243 </strong><br>
			Monday to Friday 9.00am - 22.00pm
		</p>
	</div><!-- end check avail-->
    
	<div class="facilities_desc add-bottom_2">
		<ul>
			<li>
			<h5>LCD TV</h5>
			<p>
				Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada.
			</p>
			</li>
			<li>
			<h5>Wifi broadband access</h5>
			<p>
				Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada.
			</p>
			</li>
			<li>
			<h5>Breakfast</h5>
			<p>
				Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada.
			</p>
			</li>
			<li>
			<h5>Safe-deposit box</h5>
			<p>
				Lorem ipsum dolor sit amet, pellentesque amet adipiscing scelerisque, vitae urna aenean, justo malesuada at eu, orci varius risus luctus enim a malesuada.
			</p>
			</li>
		</ul>
	</div><!-- end facilities desc-->
</section><!-- end col right -->
</div><!-- container-->

<footer>
    <div class="container">
        <nav class="eleven columns">
        <ul id="nav-footer">
            <li><a href="rooms.html">Rooms</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="rooms.html">Book now</a></li>
            <li><a href="fullscreen_gallery.html">Gallery</a></li>
            <li><a href="contacts.html">Contacts </a></li>
        </ul>
        </nav>
    <div class="five columns copy">© 2012 Paradise Hotel. All Rights Reserved.</div>
    </div>
</footer><!-- footer  -->

<!-- JQUERY plugins: Moderniz, Prettyphoto, Flexislider, MobileMenu, SuperfishMenu, Weather, Tooltip-->	
<script type="text/javascript"  src="js/plug_ins.js"></script>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script>
  $(document).ready(function(){
    $("#myform").validate();
	$(":date").dateinput();
  });
  </script>
<script src="js/functions.js"></script>
</html>